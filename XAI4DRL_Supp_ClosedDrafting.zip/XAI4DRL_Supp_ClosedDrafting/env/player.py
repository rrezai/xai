class Player:
    def __init__(self,name):
        '''
        Class to hold player-specific information such as points, hand, played cards, desserts, and memory
        :param name: string representing player name
        '''
        self.name = name
        self.points = 0
        self.hand = []
        self.played_cards = []
        self.desserts = []
        self.uramaki_count = 0
        self.uramaki_round = 1000
        self.memory = []
    def __repr__(self):
        return f"{self.name}({self.hand},{self.played_cards},{self.points},{self.desserts})"