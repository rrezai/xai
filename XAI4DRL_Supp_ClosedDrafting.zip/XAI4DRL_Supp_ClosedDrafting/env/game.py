from .cards import *
from .player import *
import random
from collections import Counter, OrderedDict
import numpy as np
import copy
from typing import NamedTuple, List

class Config(NamedTuple):
    num_players: int
    player_names: List[str]
    roll: str
    appetizer: List[str]
    special: List[str]
    dessert: str

MyFirstMeal = Config(**{
    "num_players": 4,
    "player_names": ["Player 1", "Player 2", "Player 3", "Player 4"],
    "roll": "Maki",
    "appetizer": ["Tempura","Sashimi","MisoSoup"],
    "special": ["SoySauce","Tea"],
    "dessert": "GreenTeaIceCream"
})
CutthroatCombo = Config(**{
    "num_players": 4,
    "player_names": ["Player 1", "Player 2", "Player 3", "Player 4"],
    "roll": "Temaki",
    "appetizer": ["Eel","Tofu","MisoSoup"],
    "special": ["SoySauce","Tea"],
    "dessert": "Pudding"
})

# My First Meal Config:

c1 = Config(**{
    "num_players": 4,
    "player_names": ["Player 1", "Player 2", "Player 3", "Player 4"],
    "roll": "Maki",
    "appetizer": ["Tempura","Sashimi","MisoSoup"],
    "special": ["SoySauce","Tea"],
    "dessert": "GreenTeaIceCream"
})

# Intermediaries:

c2 = Config(**{
    "num_players": 4,
    "player_names": ["Player 1", "Player 2", "Player 3", "Player 4"],
    "roll": "Temaki",
    "appetizer": ["Tempura","Sashimi","MisoSoup"],
    "special": ["SoySauce","Tea"],
    "dessert": "GreenTeaIceCream"
})

c3 = Config(**{
    "num_players": 4,
    "player_names": ["Player 1", "Player 2", "Player 3", "Player 4"],
    "roll": "Temaki",
    "appetizer": ["Eel","Sashimi","MisoSoup"],
    "special": ["SoySauce","Tea"],
    "dessert": "GreenTeaIceCream"
})

c4 = Config(**{
    "num_players": 4,
    "player_names": ["Player 1", "Player 2", "Player 3", "Player 4"],
    "roll": "Temaki",
    "appetizer": ["Eel","Tofu","MisoSoup"],
    "special": ["SoySauce","Tea"],
    "dessert": "GreenTeaIceCream"
})

# Cutthroat Combo Config:

c5 = Config(**{
    "num_players": 4,
    "player_names": ["Player 1", "Player 2", "Player 3", "Player 4"],
    "roll": "Temaki",
    "appetizer": ["Eel","Tofu","MisoSoup"],
    "special": ["SoySauce","Tea"],
    "dessert": "Pudding"
})

class SushiGoPartyGame:
    '''
    An instance of a Sushi Go Party Game, containing all game rules and states
    '''
    def __init__(self,config):
        '''
        :param config: a namedtuple containing game setup specifications. It must contain the following attributes:
            num_players: int
            player_names: str
            roll: str
            appetizer: list of str
            special: list of str
            dessert: str
        '''
        # Ensure configuration is valid
        assert (2<=config.num_players<=8)
        assert (config.num_players == len(config.player_names))
        assert (len(set(config.player_names)) == len(config.player_names))
        assert (config.roll in {"Maki","Temaki","Uramaki"})
        assert (len(config.appetizer)==3)
        assert (all(appetizer in {"Dumpling","Edamame","Eel","Onigiri","MisoSoup","Sashimi","Tempura","Tofu"} for appetizer in config.appetizer))
        assert (len(config.special)==2)
        assert (all(special in {"Chopsticks","Menu","SoySauce","Spoon","SpecialOrder","TakeoutBox","Tea","Wasabi"} for special in config.special))
        assert (config.dessert in {"GreenTeaIceCream","Pudding","Fruit"})
        assert (not (config.num_players==2 and "Spoon" in config.special))
        assert (not (config.num_players==2 and "Edamame" in config.special))
        assert (not (config.num_players>=7 and "Menu" in config.special))
        assert (not (config.num_players>=7 and "SpecialOrder" in config.special))

        self.config = config
        self.players = [Player(name) for name in config.player_names]
        for player in self.players:
            player.memory = [[] for _ in range(self.config.num_players)]
        self.round_num = 0
        self.card_num = 0

    def __repr__(self):
        return f"Game({self.round_num}-{self.card_num},{self.players})"

    def pprint(self,autoprint=True):
        '''
        Pretty print function of the game state
        '''
        output = f"Round {self.round_num}-{self.card_num}:\n\t" + "\n\t".join(
                f"{player.name}: {player.points}"
                f"\n\t\tHand:{player.hand}"
                f"\n\t\tPlayed:{player.played_cards}"
                f"\n\t\tDesserts:{player.desserts}"
                f"\n\t\tMemory:\n\t\t\t" +
                "\n\t\t\t".join(
                    str(hand) for hand in player.memory
                ) for player in self.players)
        if autoprint:
            print(output)
        else:
            return output

    def render(self): #TODO graphical interface
        pass

    def deal(self):
        '''
        This function should be called at the start of every round.
        It deals the appropriate set of cards to each player's hand.
        '''
        self.round_num+=1
        assert (1<=self.round_num<=3)
        assert (len(self.players[0].played_cards)==0)
        self.card_num = 0
        self.deck = []

        # Add nigiri
        self.deck.extend([EggNigiri() for _ in range(4)])
        self.deck.extend([SalmonNigiri() for _ in range(5)])
        self.deck.extend([SquidNigiri() for _ in range(3)])

        # Add rolls
        if self.config.roll=="Maki":
            self.deck.extend([OneMaki() for _ in range(4)]) # NEED TO ADJUST AMOUNTS
            self.deck.extend([TwoMaki() for _ in range(4)])
            self.deck.extend([ThreeMaki() for _ in range(4)])
        elif self.config.roll=="Temaki":
            self.deck.extend([Temaki() for _ in range(12)])
        else:
            self.deck.extend([ThreeUramaki() for _ in range(4)]) # NEED TO ADJUST AMOUNTS
            self.deck.extend([FourUramaki() for _ in range(4)])
            self.deck.extend([FiveUramaki() for _ in range(4)])

        # Add appetizers
        if "Dumpling" in self.config.appetizer:
            self.deck.extend([Dumpling() for _ in range(8)])
        if "Edamame" in self.config.appetizer:
            self.deck.extend([Edamame() for _ in range(8)])
        if "Eel" in self.config.appetizer:
            self.deck.extend([Eel() for _ in range(8)])
        if "Onigiri" in self.config.appetizer:
            self.deck.extend([TriangleOnigiri() for _ in range(2)])
            self.deck.extend([CircleOnigiri() for _ in range(2)])
            self.deck.extend([SquareOnigiri() for _ in range(2)])
            self.deck.extend([FlatOnigiri() for _ in range(2)])
        if "MisoSoup" in self.config.appetizer:
            self.deck.extend([MisoSoup() for _ in range(8)])
        if "Sashimi" in self.config.appetizer:
            self.deck.extend([Sashimi() for _ in range(8)])
        if "Tempura" in self.config.appetizer:
            self.deck.extend([Tempura() for _ in range(8)])
        if "Tofu" in self.config.appetizer:
            self.deck.extend([Tofu() for _ in range(8)])

        # Add specials
        if "Chopsticks" in self.config.special: #TODO add number order in bottom corner of card
            self.deck.extend([Chopsticks() for _ in range(3)])
        if "Menu" in self.config.special:
            self.deck.extend([Menu() for _ in range(3)])
        if "SoySauce" in self.config.special:
            self.deck.extend([SoySauce() for _ in range(3)])
        if "Spoon" in self.config.special:
            self.deck.extend([Spoon() for _ in range(3)])
        if "SpecialOrder" in self.config.special:
            self.deck.extend([SpecialOrder() for _ in range(3)])
        if "TakeoutBox" in self.config.special:
            self.deck.extend([TakeoutBox() for _ in range(3)])
        if "Tea" in self.config.special:
            self.deck.extend([Tea() for _ in range(3)])
        if "Wasabi" in self.config.special:
            self.deck.extend([Wasabi() for _ in range(3)])

        # Add dessert
        if self.config.dessert=="GreenTeaIceCream":
            if self.round_num==1:
                if len(self.players)<=5:
                    self.deck.extend([GreenTeaIceCream() for _ in range(5)])
                else:
                    self.deck.extend([GreenTeaIceCream() for _ in range(7)])
            elif self.round_num==2:
                if len(self.players)<=5:
                    self.deck.extend([GreenTeaIceCream() for _ in range(3)])
                else:
                    self.deck.extend([GreenTeaIceCream() for _ in range(5)])
            else:
                if len(self.players)<=5:
                    self.deck.extend([GreenTeaIceCream() for _ in range(2)])
                else:
                    self.deck.extend([GreenTeaIceCream() for _ in range(3)])
        elif self.config.dessert=="Pudding":
            if self.round_num==1:
                if len(self.players)<=5:
                    self.deck.extend([Pudding() for _ in range(5)])
                else:
                    self.deck.extend([Pudding() for _ in range(7)])
            elif self.round_num==2:
                if len(self.players)<=5:
                    self.deck.extend([Pudding() for _ in range(3)])
                else:
                    self.deck.extend([Pudding() for _ in range(5)])
            else:
                if len(self.players)<=5:
                    self.deck.extend([Pudding() for _ in range(2)])
                else:
                    self.deck.extend([Pudding() for _ in range(3)])
        elif self.config.dessert=="Fruit":
            if self.round_num==1:
                self.fruits = []
                self.fruits.extend([TwoWatermelonFruit() for _ in range(2)])
                self.fruits.extend([TwoPineappleFruit() for _ in range(2)])
                self.fruits.extend([TwoOrangeFruit() for _ in range(2)])
                self.fruits.extend([WatermelonPineapleFruit() for _ in range(3)])
                self.fruits.extend([WatermelonOrangeFruit() for _ in range(3)])
                self.fruits.extend([PineappleOrangeFruit() for _ in range(3)])
                random.shuffle(self.fruits)
                if len(self.players)<=5:
                    self.deck.extend([self.fruits.pop() for _ in range(5)])
                else:
                    self.deck.extend([self.fruits.pop() for _ in range(7)])
            elif self.round_num==2:
                if len(self.players)<=5:
                    self.deck.extend([self.fruits.pop() for _ in range(3)])
                else:
                    self.deck.extend([self.fruits.pop() for _ in range(5)])
            else:
                if len(self.players)<=5:
                    self.deck.extend([self.fruits.pop() for _ in range(2)])
                else:
                    self.deck.extend([self.fruits.pop() for _ in range(3)])

        # Deal
        random.shuffle(self.deck)
        for i in range(len(self.players)):
            if len(self.players)<=3:
                self.players[i].hand = [self.deck.pop() for _ in range(10)]
            elif len(self.players)<=5:
                self.players[i].hand = [self.deck.pop() for _ in range(9)]
            elif len(self.players)<=7:
                self.players[i].hand = [self.deck.pop() for _ in range(8)]
            else:
                self.players[i].hand = [self.deck.pop() for _ in range(7)]

        # Reset Memory
        for player in self.players:
            player.memory = [[] for _ in range(self.config.num_players)]
            player.memory[0] = copy.deepcopy(player.hand)

    def requestActions(self,special=None): #TODO add special actions
        if special=="":
            pass
        else: #normal card
            actions = []
            for i in range(len(self.players)):
                pass
            return actions

    def play(self,actions): #TODO add special cards
        '''
        Plays the cards each player has selected
        :param actions: a list of card ids chosen by each player
        '''
        self.card_num+=1

        # Make sure there are still cards left to play
        if len(self.players) <= 3:
            assert (self.card_num<=10)
        elif len(self.players) <= 5:
            assert (self.card_num<=9)
        elif len(self.players) <= 7:
            assert (self.card_num<=8)
        else:
            assert (self.card_num<=7)

        # Convert actions to card indices (index will throw error if invalid action)
        action_indices = [self.players[i].hand.index(id_to_card[action]()) for i, action in enumerate(actions)]

        # Special card actions
        # Special Order
        special_order_players = [i for i in range(len(self.players)) if isinstance(id_to_card[actions[i]](),SpecialOrder)]
        for i in special_order_players:
            pass
            # actions[i] = gatherAction() #TODO

        # Uramaki
        uramaki_players = [(i,actions[i].count) for i in range(len(self.players)) if isinstance(id_to_card[actions[i]](), Uramaki)]
        for i,count in uramaki_players:
            pass
            # self.players[i].uramaki_count += count
            # if self.players[i].uramaki_count>=10:
            #     self.players[i].uramaki_round = self.card_num

        # Miso
        miso_players = [i for i in range(len(self.players)) if isinstance(id_to_card[actions[i]](),MisoSoup)]
        if len(miso_players)==1:
            pass
            # actions[miso_players[0]].success = True

        # Wasabi

        # Chopsticks

        # Menu

        # Spoon

        # Takeout Box

        # Put card into played cards
        for i in range(len(self.players)):
            self.players[i].played_cards.append(self.players[i].hand.pop(action_indices[i]))

        # Pass cards
        temp = self.players[-1].hand
        for i in range(len(self.players)-1,0,-1):
            self.players[i].hand = self.players[i-1].hand
        self.players[0].hand = temp

        # Update memory
        for playerIndex in range(self.config.num_players):
            observation_order = [(playerIndex + i) % self.config.num_players for i in range(self.config.num_players)]
            # Remove played cards from memory
            for relPos,fixPos in enumerate(observation_order):
                played_card = id_to_card[actions[fixPos]]()
                if played_card in self.players[playerIndex].memory[relPos]:
                    action_index = self.players[playerIndex].memory[relPos].index(played_card)
                    self.players[playerIndex].memory[relPos].pop(action_index)
            # TODO special actions
            # Rotate
            self.players[playerIndex].memory = self.players[playerIndex].memory[-1:] + self.players[playerIndex].memory[:-1]
            # Update current
            self.players[playerIndex].memory[0] = copy.deepcopy(self.players[playerIndex].hand)

    def score(self,update=True,reward_shaping=False):
        '''
        Calculate point totals for the round. Must be called at the end of a round.
        :param update: whether to update player point totals
        :return:
        '''
        point_totals = [0 for _ in range(self.config.num_players)]

        # Make sure all rounds have been played
        if len(self.players) <= 3:
            assert (self.card_num == 10)
        elif len(self.players) <= 5:
            assert (self.card_num == 9)
        elif len(self.players) <= 7:
            assert (self.card_num == 8)
        else:
            assert (self.card_num == 7)

        # Convert played cards into nice dict format
        played_hands = [Counter(player.played_cards) for player in self.players]

        # Simple scoring
        for i in range(self.config.num_players):
            for kind in played_hands[i]:
                if hasattr(kind,"score"):
                    point_totals[i] += kind.score(played_hands[i][kind])

        # Rolls
        if self.config.roll=="Maki":
            counts = [played_hands[i][OneMaki()]+2*played_hands[i][TwoMaki()]+3*played_hands[i][ThreeMaki()] for i in range(self.config.num_players)]
            first = max(counts)
            temp = set(counts)
            temp.remove(first)
            if len(temp)>1:
                second = max(temp)
                temp.remove(second)
            else:
                second = 0
            if len(temp)>1:
                third = max(temp)
                temp.remove(third)
            else:
                third = 0
            for i in range(self.config.num_players):
                if self.config.num_players<=5:
                    if counts[i] == first and first>=1:
                        point_totals[i] += 6
                    if counts[i] == second and second>=1:
                        point_totals[i] += 3
                else:
                    if counts[i] == first and first >= 1:
                        point_totals[i] += 6
                    if counts[i] == second and second >= 1:
                        point_totals[i] += 4
                    if counts[i] == third and third >= 1:
                        point_totals[i] += 2
        elif self.config.roll=="Temaki":
            counts = [played_hands[i][Temaki()] for i in range(self.config.num_players)]
            for i in range(self.config.num_players):
                if counts[i]==max(counts):
                    point_totals[i] += 4
                if counts[i]==min(counts) and self.config.num_players!=2:
                    point_totals[i] -= 4
        else:
            pass

        # Onigiri
        for i in range(self.config.num_players):
            counts = [played_hands[i][TriangleOnigiri()],played_hands[i][SquareOnigiri()],played_hands[i][CircleOnigiri()],played_hands[i][FlatOnigiri()]]
            point_totals[i] += Onigiri.special_score(counts)

        # Soy Sauce
        num_colors = [len(set(card.background for card in played_hands[i].keys() if card.background is not None)) for i in range(self.config.num_players)]
        for i in range(self.config.num_players):
            if num_colors[i]==max(num_colors):
                point_totals[i] += 4*played_hands[i][SoySauce()]

        # Tea
        for i in range(self.config.num_players):
            point_totals[i] += len(set(card.background for card in played_hands[i].keys() if card.background is not None))*played_hands[i][Tea()]

        # Move desserts to desserts
        for i in range(len(self.players)):
            for j in range(len(self.players[i].played_cards)):
                if self.players[i].played_cards[j].category=="dessert":
                    self.players[i].desserts.append(self.players[i].played_cards[j])

        # If last round, score desserts
        if self.round_num==3:
            if self.config.dessert=="GreenTeaIceCream":
                for i in range(self.config.num_players):
                    point_totals[i] += GreenTeaIceCream.special_score(len(self.players[i].desserts))
            elif self.config.dessert=="Pudding":
                counts = [len(player.desserts) for player in self.players]
                for i in range(self.config.num_players):
                    if counts[i] == max(counts):
                        point_totals[i] += 6
                    if counts[i] == min(counts):
                        point_totals[i] -= 6
            else:
                for i in range(self.config.num_players):
                    point_totals[i] += Fruit.special_score(Counter(self.players[i].desserts))

        # Clear played cards
        for i in range(self.config.num_players):
            self.players[i].played_cards = []

        # Update scores
        if update:
            for i in range(self.config.num_players):
                self.players[i].points += point_totals[i]

        if reward_shaping and self.round_num==3:
            winner = np.argmax([self.players[i].points for i in range(self.config.num_players)])
            point_totals[winner]+=100

        return point_totals

    def encode(self,cards):
        '''
        Convert a list of cards to a one-hot encoded vector [Number of Egg Nigiri, Number of Salmon Nigiri, ...]
        :param cards: list of card objects
        :return: list of card counts
        '''
        one_hot = [0 for _ in range(37)]
        for card in cards:
            one_hot[card.id]+=1
        return np.array(one_hot)

    def decode(self,one_hot):
        '''
        Convert a one-hot encoded vector [Number of Egg Nigiri, Number of Salmon Nigiri, ...] to a list of cards
        :param one_hot: list of card counts
        :return: list of card objects
        '''
        cards = []
        for i,index in enumerate(one_hot):
            cards.extend([id_to_card[i]() for _ in range(index)])
        return cards

    def encode_observation(self,observation):
        '''
        :param observation: a dictionary of observations
        :return: a single np array that encompasses the observations
        '''
        # for key in observation:
        #     print(key,observation[key].shape)
        flattened = np.concatenate([
            observation["hands"],
            observation["played_cards"],
            observation["desserts"],
            observation["points"],
            [observation["round"]],
            [observation["card_num"]]
        ])
        return flattened

    def decode_observation(self,flattened):
        '''
        :param observation: a single np array that encompasses the observations
        :return: a dictionary of observations
        '''
        observation = {}
        start_index = 0
        observation["hands"] = [self.decode(flattened[start_index+i*37:start_index+(i+1)*37]) for i in range(self.config.num_players)]
        start_index = self.config.num_players*37
        observation["played_cards"] = [self.decode(flattened[start_index+i*37:start_index+(i+1)*37]) for i in range(self.config.num_players)]
        start_index = 2*self.config.num_players*37
        observation["desserts"] = [self.decode(flattened[start_index+i*37:start_index+(i+1)*37]) for i in range(self.config.num_players)]
        start_index = 3*self.config.num_players*37
        observation["points"] = flattened[start_index:start_index+self.config.num_players]
        observation["round"] = flattened[-2]
        observation["card_num"] = flattened[-1]
        return observation

    def get_observations(self,playerIndex,memory=True):
        '''
        Get all observations observable by the 'playerIndex'th player
        :param playerIndex: the index of the player whose observations to return
        :return: OrderedDict observation with the following fields (observation order starts with self, increases modularly)
            hands: known cards encoded for each player in observation order
            played_cards: played cards encoded for each player in observation order
            desserts: desserts from past round encoded for each player in observation order
            points: number of points for each player in observation order
            round: round number
            card_num: card number
            action_mask: boolean mask [has EggNigiri in hand, has SalmonNigiri in hand, ...]
        '''
        observation_order = [(playerIndex + i) % self.config.num_players for i in range(self.config.num_players)]
        return OrderedDict(sorted({
            "observation": self.encode_observation({
                "hands": np.array([self.encode(mem) if (i==0 or memory) else np.zeros(37) for i,mem in enumerate(self.players[playerIndex].memory)]).flatten(),
                "played_cards": np.array([self.encode(self.players[i].played_cards) for i in observation_order]).flatten(),
                "desserts": np.array([self.encode(self.players[i].desserts) for i in observation_order]).flatten(),
                "points": np.array([self.players[i].points for i in observation_order]),
                "round": self.round_num,
                "card_num": self.card_num,
            }),
            "action_mask": np.array(self.encode(set(self.players[playerIndex].hand)),dtype=np.int8),
        }.items()))

    def get_rewards(self,reward_shaping=True):
        '''
        Return rewards for all players
        Reward is 0 if not at round end, otherwise the points gained in that round if at round end
        :return: list of ints representing reward for each player
        '''
        # If end of round, return score
        if len(self.players) <= 3:
            if self.card_num==10:
                return self.score(update=True,reward_shaping=reward_shaping)
        elif len(self.players) <= 5:
            if self.card_num == 9:
                return self.score(update=True,reward_shaping=reward_shaping)
        elif len(self.players) <= 7:
            if self.card_num == 8:
                return self.score(update=True,reward_shaping=reward_shaping)
        else:
            if self.card_num == 7:
                return self.score(update=True,reward_shaping=reward_shaping)

        # Not end of round, so return 0s
        return [0 for _ in range(self.config.num_players)]

if __name__ == "__main__":
    # Just print starting hands
    config = MyFirstMeal
    game = SushiGoPartyGame(config)
    game.deal()
    game.play([player.hand[0].id for player in game.players])
    game.get_observations(0)
    game.pprint()

    # Play interactively
    # config = Config(**config)
    # game = SushiGoPartyGame(config)
    # for round in range(3):
    #     game.deal()
    #     game.pprint()
    #     for turn in range(9):
    #         actions = [int(input()) for _ in range(4)]
    #         game.play(actions)
    #         game.pprint()
    #     game.score()
    #     game.pprint()

    # Play fixed
    # config = Config(**config)
    # game = SushiGoPartyGame(config)
    # for round in range(3):
    #     game.deal()
    #     game.pprint()
    #     for turn in range(9):
    #         actions = [player.hand[0].id for player in game.players]
    #         game.play(actions)
    #         game.pprint()
    #     game.score()
    #     game.pprint()
