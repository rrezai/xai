import functools
import logging

import gymnasium
from gymnasium.spaces import Discrete, MultiDiscrete, Sequence, Dict, MultiBinary

from pettingzoo import ParallelEnv
from pettingzoo.utils import parallel_to_aec, wrappers, aec_to_parallel
from pettingzoo.test import parallel_api_test, api_test

from .game import *

def env(config,render_mode=None):
    """
    The env function often wraps the environment in wrappers by default.
    You can find full documentation for these methods
    elsewhere in the developer documentation.
    """
    internal_render_mode = render_mode if render_mode != "ansi" else "human"
    env = raw_env(config,render_mode=internal_render_mode)
    # This wrapper is only for environments which print results to the terminal
    # if render_mode == "ansi":
        # env = wrappers.CaptureStdoutWrapper(env)
    # this wrapper helps error handling for discrete action spaces
    # env = wrappers.AssertOutOfBoundsWrapper(env)
    # Provides a wide variety of helpful user errors
    # Strongly recommended
    # env = wrappers.OrderEnforcingWrapper(env)
    # Flatten Dict
    # env = FlattenObservation(env)
    return env


def raw_env(config,render_mode=None):
    """
    To support the AEC API, the raw_env() function just uses the from_parallel
    function to convert from a ParallelEnv to an AEC env
    """
    env = SushiGoPartyEnv(config,render_mode=render_mode)
    # env = parallel_to_aec(env)
    # env = aec_to_parallel(env)
    return env

class SushiGoPartyEnv(ParallelEnv):
    metadata = {"render_modes": ["human"], "name": "rps_v2"}

    def __init__(self, config, render_mode=None, save_render=None):
        """
        The init method takes in environment arguments and should define the following attributes:
        - possible_agents
        - action_spaces
        - observation_spaces
        These attributes should not be changed after initialization.
        """
        self.config = config
        self.game = SushiGoPartyGame(self.config)
        self.possible_agents = self.config.player_names
        self.agent_selection = None
        self.agent_name_mapping = dict(
            zip(self.possible_agents, list(range(len(self.possible_agents))))
        )
        self.render_mode = render_mode
        self.save_render = save_render

        if save_render is not None:
            logging.basicConfig(filename=save_render, encoding='utf-8', level=logging.INFO, format='%(message)s')

    # this cache ensures that same space object is returned for the same agent
    # allows action space seeding to work as expected
    @functools.lru_cache(maxsize=None)
    def observation_space(self, agent):
        # gymnasium spaces are defined and documented here: https://gymnasium.farama.org/api/spaces/
        return Dict({
            "observation": MultiDiscrete([11 for _ in range(37 * self.config.num_players)]+ #hands
                             [11 for _ in range(37 * self.config.num_players)]+ #played_cards
                             [16 for _ in range(37 * self.config.num_players)]+ #desserts
                             [300 for _ in range(self.config.num_players)]+ #points
                             [4]+ #round
                             [11] #card_num
                            ),
            "action_mask": MultiBinary([37]),
        })
        # return Dict({
        #     "observation": flatten_space(Dict({
        #         "hands": MultiDiscrete([11 for _ in range(37*self.config.num_players)]),
        #         "played_cards": MultiDiscrete([11 for _ in range(37 * self.config.num_players)]),
        #         "desserts": MultiDiscrete([16 for _ in range(37 * self.config.num_players)]),
        #         "points": MultiDiscrete([300 for _ in range(self.config.num_players)]),
        #         "round": Discrete(4, start=0),
        #         "card_num": Discrete(11,start=0),
        #     })),
        #     "action_mask": MultiBinary([37]),
        # })

    @functools.lru_cache(maxsize=None)
    def action_space(self, agent):
        return Discrete(37) #37 kinds of cards to play

    def render(self):
        """
        Renders the environment. In human mode, it can print to terminal, open
        up a graphical window, or open up some other display that a human can see and understand.
        """
        if self.render_mode is None:
            gymnasium.logger.warn(
                "You are calling render method without specifying any render mode."
            )
        elif self.render_mode == "ansi":
            self.game.pprint()
        elif self.render_mode == "file":
            logging.info(self.game.pprint(autoprint=False))
        else:
            gymnasium.logger.warn(
                f"You are calling render method with unsupported render mode {self.render_mode}."
            )

    def close(self):
        """
        Close should release any graphical displays, subprocesses, network connections
        or any other environment data which should not be kept around after the
        user is no longer using the environment.
        """
        pass

    def reset(self, seed=None, return_info=True, options=None):
        """
        Reset needs to initialize the `agents` attribute and must set up the
        environment so that render(), and step() can be called without issues.
        Returns the observations for each agent
        """
        self.game = SushiGoPartyGame(self.config)
        self.game.deal()
        self.agents = self.possible_agents[:]
        self.num_moves = 0
        observations = {agent: self.game.get_observations(self.agent_name_mapping[agent]) for agent in self.agents}

        if not return_info:
            return observations
        else:
            infos = {agent: {} for agent in self.agents}
            return observations, infos

    def step(self, actions):
        """
        step(action) takes in an action for each agent and should return the
        - observations
        - rewards
        - terminations
        - truncations
        - infos
        dicts where each dict looks like {agent_1: item_1, agent_2: item_2}
        """
        # If a user passes in actions with no agents, then just return empty observations, etc.
        if not actions:
            self.agents = []
            return {}, {}, {}, {}, {}

        # process card plays
        actions_list = [0 for _ in range(self.config.num_players)]
        for agent, action in actions.items():
            actions_list[self.agent_name_mapping[agent]] = action
        self.game.play(actions_list)

        # termination and truncation (https://gymnasium.farama.org/tutorials/gymnasium_basics/handling_time_limits/)

        terminations = {agent: False for agent in self.agents}

        env_truncation = False  # no truncation since games take constant number of turns
        truncations = {agent: env_truncation for agent in self.agents}

        # typically there won't be any information in the infos, but there must
        # still be an entry for each agent
        infos = {agent: {} for agent in self.agents}

        # rewards for all agents are placed in the rewards dictionary to be returned
        points = self.game.get_rewards()
        rewards = {agent: points[i] for i,agent in enumerate(self.agents)}

        if self.config.num_players <= 3:
            if self.game.card_num == 10:
                if self.game.round_num == 3:
                    terminations = {agent: True for agent in self.agents}
                else:
                    self.game.deal()
        elif self.config.num_players <= 5:
            if self.game.card_num == 9:
                if self.game.round_num == 3:
                    terminations = {agent: True for agent in self.agents}
                else:
                    self.game.deal()
        elif self.config.num_players <= 7:
            if self.game.card_num == 8:
                if self.game.round_num == 3:
                    terminations = {agent: True for agent in self.agents}
                else:
                    self.game.deal()
        else:
            if self.game.card_num == 7:
                if self.game.round_num == 3:
                    terminations = {agent: True for agent in self.agents}
                else:
                    self.game.deal()

        # query for next observation
        observations = {agent: self.game.get_observations(self.agent_name_mapping[agent]) for agent in self.agents}

        if env_truncation:
            self.agents = []

        if self.render_mode == "human":
            self.render()

        for agent in terminations:
            if terminations[agent]:
                self.agents.remove(agent)

        return observations, rewards, terminations, truncations, infos

if __name__ == "__main__":
    # # Parallel API Test
    # sushi_env = env(config)
    # parallel_api_test(sushi_env)

    # # Parallel API Random Sampler
    # sushi_env = env(config)
    # observations, infos = sushi_env.reset()
    # while sushi_env.agents:
    #     for agent in sushi_env.agents:
    #         print(agent)
    #         print(sushi_env.game.decode_observation(observations[agent]["observation"]))
    #         print()
    #     actions = {agent: sushi_env.action_space(agent).sample(observations[agent]["action_mask"]) for agent in sushi_env.agents}
    #     observations, rewards, terminations, truncations, infos = sushi_env.step(actions)
    # sushi_env.close()

    # AEC API Test
    sushi_env = parallel_to_aec(env(config))
    api_test(sushi_env)

    # # AEC API Random Sampler
    # sushi_env.reset()
    # for agent in sushi_env.agent_iter():
    #     observation, reward, termination, truncation, info = sushi_env.last()
    #     print(agent)
    #     print(sushi_env.unwrapped.game.decode_observation(observation["observation"]))
    #     print()
    #     if termination or truncation:
    #         action = None
    #     else:
    #         action = sushi_env.action_space(agent).sample(observation["action_mask"])  # this is where you would insert your policy
    #
    #     sushi_env.step(action)
    # sushi_env.close()