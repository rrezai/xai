class Card:
    def __init__(self,category,background,id):
        '''
        Parent class to all cards
        :param category: str of either nigiri, roll, appetizer, special, or dessert
        :param background: str to image file
        :param id: int that is unique identifier for each kind of card
        '''
        self.category = category
        self.id = id
        self.takeout = False
        self.background = None
        self.image = None
    def __repr__(self):
        return self.__class__.__name__
    # Functions such that cards can be hashable objects
    def __hash__(self):
        return hash(repr(self))
    def __eq__(self, other):
        return self.__hash__()==other.__hash__()

class EggNigiri(Card):
    def __init__(self):
        super().__init__("nigiri","nigiri",0)
    @staticmethod
    def score(num):
        return num

class SalmonNigiri(Card):
    def __init__(self):
        super().__init__("nigiri","nigiri",1)
    @staticmethod
    def score(num):
        return num*2

class SquidNigiri(Card):
    def __init__(self):
        super().__init__("nigiri","nigiri",2)
    @staticmethod
    def score(num):
        return num*3

class Maki(Card):
    def __init__(self,category,id):
        super().__init__(category,"maki",id)
        self.count = 0

class OneMaki(Maki):
    def __init__(self):
        super().__init__("roll",3)
        self.count = 1

class TwoMaki(Maki):
    def __init__(self):
        super().__init__("roll",4)
        self.count = 2

class ThreeMaki(Maki):
    def __init__(self):
        super().__init__("roll",5)
        self.count = 3

class Temaki(Card):
    def __init__(self):
        super().__init__("roll","temaki",6)

class Uramaki(Card):
    def __init__(self,category,id):
        super().__init__(category,"uramaki",id)
        self.count = 0

class ThreeUramaki(Uramaki):
    def __init__(self):
        super().__init__("roll",7)
        self.count = 3

class FourUramaki(Uramaki):
    def __init__(self):
        super().__init__("roll", 8)
        self.count = 4

class FiveUramaki(Uramaki):
    def __init__(self):
        super().__init__("roll", 9)
        self.count = 5

class Dumpling(Card):
    def __init__(self):
        super().__init__("appetizer","dumpling",10)
    @staticmethod
    def score(num):
        if num==1:
            return 1
        elif num==2:
            return 3
        elif num==3:
            return 6
        elif num==4:
            return 10
        elif num>=5:
            return 15

class Edamame(Card):
    def __init__(self):
        super().__init__("appetizer","edamame",11)

class Eel(Card):
    def __init__(self):
        super().__init__("appetizer","eel",12)
    @staticmethod
    def score(num):
        if num==1:
            return -3
        elif num>=2:
            return 7

def min_excluding_zero(items):
    items = [_ for _ in items if _!=0]
    if len(items)==0:
        return 0
    return min(items)

class Onigiri(Card):
    def __init__(self,category,id):
        super().__init__(category,"onigiri",id)
    @staticmethod
    def special_score(counts):
        total = 0
        while counts.count(0)==0:
            total += min_excluding_zero(counts)*16
            counts = [max(0,count-min_excluding_zero(counts)) for count in counts]
        while counts.count(0)==1:
            total += min_excluding_zero(counts)*9
            counts = [max(0,count-min_excluding_zero(counts)) for count in counts]
        while counts.count(0)==2:
            total += min_excluding_zero(counts)*4
            counts = [max(0,count-min_excluding_zero(counts)) for count in counts]
        while counts.count(0)==3:
            total += min_excluding_zero(counts)
            counts = [max(0,count-min_excluding_zero(counts)) for count in counts]
        return total

class TriangleOnigiri(Onigiri):
    def __init__(self):
        super().__init__("appetizer", 13)

class CircleOnigiri(Onigiri):
    def __init__(self):
        super().__init__("appetizer", 14)

class SquareOnigiri(Onigiri):
    def __init__(self):
        super().__init__("appetizer", 15)

class FlatOnigiri(Onigiri):
    def __init__(self):
        super().__init__("appetizer", 16)

class MisoSoup(Card):
    def __init__(self):
        super().__init__("appetizer", "miso", 17)
    @staticmethod
    def score(num):
        return num*3

class Sashimi(Card):
    def __init__(self):
        super().__init__("appetizer", "sashimi", 18)
    @staticmethod
    def score(num):
        return 10*(num//3)

class Tempura(Card):
    def __init__(self):
        super().__init__("appetizer", "tempura", 19)
    @staticmethod
    def score(num):
        return 5*(num//2)

class Tofu(Card):
    def __init__(self):
        super().__init__("appetizer", "tofu", 20)
    @staticmethod
    def score(num):
        if num==1:
            return 2
        elif num==2:
            return 6
        else:
            return 0

class Chopsticks(Card):
    def __init__(self):
        super().__init__("special", "chopsticks", 21)

class Menu(Card):
    def __init__(self):
        super().__init__("special", "menu", 22)

class SoySauce(Card):
    def __init__(self):
        super().__init__("special", "soysauce", 23)

class Spoon(Card):
    def __init__(self):
        super().__init__("special", "spoon", 24)

class SpecialOrder(Card):
    def __init__(self):
        super().__init__("special", "specialorder", 25)
        self.mimic = None

class TakeoutBox(Card):
    def __init__(self):
        super().__init__("special", "takeoutbox", 26)

class Tea(Card):
    def __init__(self):
        super().__init__("special", "tea", 27)

class Wasabi(Card):
    def __init__(self):
        super().__init__("special", "nigiri", 28)
        self.nigiri = None

class GreenTeaIceCream(Card):
    def __init__(self):
        super().__init__("dessert", "icecream", 29)
    @staticmethod
    def special_score(num):
        return 12*(num//4)

class Pudding(Card):
    def __init__(self):
        super().__init__("dessert", "pudding", 30)

class Fruit(Card):
    def __init__(self,category,id):
        super().__init__(category,"fruit",id)
        self.watermelon = 0
        self.pineapple = 0
        self.orange = 0
    @staticmethod
    def special_score(counts):
        watermelons = 2*counts[TwoWatermelonFruit()]+counts[WatermelonPineapleFruit()]+counts[WatermelonOrangeFruit()]
        pineapples = 2*counts[TwoPineappleFruit()]+counts[WatermelonPineapleFruit()]+counts[PineappleOrangeFruit()]
        oranges = 2*counts[TwoOrangeFruit()]+counts[WatermelonOrangeFruit()]+counts[PineappleOrangeFruit()]
        total = 0
        if watermelons==0:
            total-=2
        elif watermelons==1:
            total+=0
        elif watermelons==2:
            total+=1
        elif watermelons==3:
            total+=3
        elif watermelons==4:
            total+=6
        else:
            total+=10
        if pineapples==0:
            total-=2
        elif pineapples==1:
            total+=0
        elif pineapples==2:
            total+=1
        elif pineapples==3:
            total+=3
        elif pineapples==4:
            total+=6
        else:
            total+=10
        if oranges==0:
            total-=2
        elif oranges==1:
            total+=0
        elif oranges==2:
            total+=1
        elif oranges==3:
            total+=3
        elif oranges==4:
            total+=6
        else:
            total+=10
        return total

class TwoWatermelonFruit(Fruit):
    def __init__(self):
        super().__init__("dessert", 31)
        self.watermelon = 2

class TwoPineappleFruit(Fruit):
    def __init__(self):
        super().__init__("dessert", 32)
        self.pineapple = 2

class TwoOrangeFruit(Fruit):
    def __init__(self):
        super().__init__("dessert", 33)
        self.orange = 2

class WatermelonPineapleFruit(Fruit):
    def __init__(self):
        super().__init__("dessert", 34)
        self.watermelon = 1
        self.pineapple = 1

class WatermelonOrangeFruit(Fruit):
    def __init__(self):
        super().__init__("dessert", 35)
        self.watermelon = 1
        self.orange = 1

class PineappleOrangeFruit(Fruit):
    def __init__(self):
        super().__init__("dessert", 36)
        self.pineapple = 1
        self.orange = 1

# class NullCard(Card):
#     def __init__(self):
#         super().__init__(None,None,37)

id_to_card = {
    0: EggNigiri,
    1: SalmonNigiri,
    2: SquidNigiri,
    3: OneMaki,
    4: TwoMaki,
    5: ThreeMaki,
    6: Temaki,
    7: ThreeUramaki,
    8: FourUramaki,
    9: FiveUramaki,
    10: Dumpling,
    11: Edamame,
    12: Eel,
    13: TriangleOnigiri,
    14: CircleOnigiri,
    15: SquareOnigiri,
    16: FlatOnigiri,
    17: MisoSoup,
    18: Sashimi,
    19: Tempura,
    20: Tofu,
    21: Chopsticks,
    22: Menu,
    23: SoySauce,
    24: Spoon,
    25: SpecialOrder,
    26: TakeoutBox,
    27: Tea,
    28: Wasabi,
    29: GreenTeaIceCream,
    30: Pudding,
    31: TwoWatermelonFruit,
    32: TwoPineappleFruit,
    33: TwoOrangeFruit,
    34: WatermelonPineapleFruit,
    35: WatermelonOrangeFruit,
    36: PineappleOrangeFruit,
}

if __name__ == "__main__":
    print([id_to_card[num] for num in [1, 2, 20, 13, 14, 15, 16, 17, 19, 10, 5, 4, 3, 18, 12, 28, 29, 0, 11, 27, 9, 8, 7, 31, 32, 33, 34, 35, 36, 23, 26, 6, 30]])
    print([id_to_card[num] for num in [2, 1, 20, 13, 14, 15, 16, 17, 18, 5, 4, 3, 12, 19, 28, 29, 10, 9, 8, 7, 0, 27, 11, 31, 32, 33, 34, 35, 36, 6, 23, 30, 26]])

