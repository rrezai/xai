import argparse
import time
import dill as pickle
from env.sushi_go import SushiGoPartyEnv
from env.game import MyFirstMeal, CutthroatCombo
from pettingzoo.utils.conversions import parallel_to_aec
from tianshou.env import PettingZooEnv, DummyVectorEnv
from tianshou.data import Collector, Batch
from tianshou.policy import MultiAgentPolicyManager, RandomPolicy
import numpy as np
import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt
import copy
import pandas as pd
from DRNet import train, DRNet, transform_dataset
from torch.utils.data import TensorDataset
from skrules import SkopeRules
from sklearn.metrics import classification_report
from env.cards import *
from tqdm import tqdm
from utils import *

'''
Usage: python interpretability.py --save_name results/MyFirstMeal/dqn_explicit --config MyFirstMeal
ASSUMES TRAINED AGENT IS LAST COLUMN
'''

def masked_log_softmax(vector, mask, dim: int = -1) -> torch.Tensor:
    vector = torch.tensor(vector)
    mask = torch.tensor(mask)
    if mask is not None:
        mask = mask.float()
        while mask.dim() < vector.dim():
            mask = mask.unsqueeze(1)
        vector = vector + ((1-mask) * -1e32)
    return F.softmax(vector, dim=dim)

def get_env(config,render_mode=None):
    if config=="MyFirstMeal":
        config = MyFirstMeal
    elif config=="CutthroatCombo":
        config = CutthroatCombo
    else:
        raise NotImplementedError(f"Config {config} not supported.")
    env = SushiGoPartyEnv(config, render_mode=render_mode)
    env = parallel_to_aec(env)
    env = PettingZooEnv(env)
    return env

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--save_name", type=str, required=True, help="Save results to filename")
    parser.add_argument("--config", type=str, required=True, help="Which config it was trained on")
    args = parser.parse_args()

    with open(f"agents/{args.config}/{args.save_name}/{args.save_name}_agent_0.pickle", "rb") as f:
        agent = pickle.load(f)

    dataset = []
    labels = []

    example_env = SushiGoPartyEnv(eval(args.config))
    decode_observation = example_env.game.decode_observation
    decode = example_env.game.decode
    example_env.game.deal()
    possible_cards = set(example_env.game.deck)
    for i in range(len(example_env.game.players)):
        possible_cards = possible_cards.union(example_env.game.players[i].hand)

    num_samples = 10000
    for i in tqdm(range(num_samples)):
        env = get_env(args.config)
        policy = MultiAgentPolicyManager([RandomPolicy(),RandomPolicy(),RandomPolicy(),RandomPolicy()], env)
        env = DummyVectorEnv([lambda: env])
        collector = Collector(policy, env)
        # steps = [19, 23, 27, 31, 55, 59, 63, 71, 91, 95, 99, 103]
        # steps = np.arange(3,108,4)
        steps = [103]
        collector.collect(n_step=steps[np.random.randint(0,len(steps))], render=None)
        base = np.argmax(masked_log_softmax(agent(Batch(obs=collector.data.obs,info=None)).logits.detach(),collector.data.obs.mask).numpy().flatten())
        dataset.append(list(collector.data.obs.obs[0].flatten()))
        labels.append(base)

    X_train, Y_train = dataset[:int(num_samples*0.9)], labels[:int(num_samples*0.9)]
    X_test, Y_test = dataset[int(num_samples*0.9):], labels[int(num_samples*0.9):]

    # with open("temp.pickle","wb") as f:
    #     pickle.dump((X_train,Y_train,X_test,Y_test),f)

    # with open("temp.pickle","rb") as f:
    #     X_train,Y_train,X_test,Y_test = pickle.load(f)

    classifiers = []
    card_names = []
    for card in possible_cards:
        clf = SkopeRules(max_depth_duplication=2,
                         n_estimators=30,
                         precision_min=0.3,
                         recall_min=0.3,
                         random_state=111,
                         feature_names=[f"Hand_1_{id_to_card[i].__name__}" for i in range(37)]+
                                       [f"Hand_2_{id_to_card[i].__name__}" for i in range(37)]+
                                       [f"Hand_3_{id_to_card[i].__name__}" for i in range(37)]+
                                       [f"Hand_4_{id_to_card[i].__name__}" for i in range(37)]+
                                       [f"Played_1_{id_to_card[i].__name__}" for i in range(37)]+
                                       [f"Played_2_{id_to_card[i].__name__}" for i in range(37)] +
                                       [f"Played_3_{id_to_card[i].__name__}" for i in range(37)] +
                                       [f"Played_4_{id_to_card[i].__name__}" for i in range(37)] +
                                       [f"Desserts_1_{id_to_card[i].__name__}" for i in range(37)] +
                                       [f"Desserts_2_{id_to_card[i].__name__}" for i in range(37)] +
                                       [f"Desserts_3_{id_to_card[i].__name__}" for i in range(37)] +
                                       [f"Desserts_4_{id_to_card[i].__name__}" for i in range(37)] +
                                       [f"Points_{i}" for i in range(4)] +
                                       ["Round_Num"] +
                                       ["Card_Num"])
        try:
            clf.fit(np.array(X_train), np.array(Y_train) == card.id)
            rules = clf.rules_
            print(f"Rules for choosing {card}")
            for rule in rules:
                print(rule)
            print()
            print(20 * '=')
            print()
            classifiers.append(clf)
            card_names.append(card)
        except:
            print(f"No rules for choosing {card}")

    predictions = np.argmax(np.array([clf.score_top_rules(X_train) for clf in classifiers]),axis=0)
    print(classification_report(Y_train, predictions,target_names=[str(id_to_card[i].__name__) for i in sorted(list(set(card.id for card in possible_cards)))],labels=sorted(list(set(card.id for card in possible_cards)))))
    predictions = np.argmax(np.array([clf.score_top_rules(X_test) for clf in classifiers]), axis=0)
    print(classification_report(Y_test, predictions, target_names=[str(id_to_card[i].__name__) for i in sorted(
        list(set(card.id for card in possible_cards)))], labels=sorted(list(set(card.id for card in possible_cards)))))

# #DRNET
    # train_set = TensorDataset(torch.tensor(X_train).float(), torch.tensor(Y_train).float())
    # test_set = TensorDataset(torch.tensor(X_test).float(), torch.tensor(Y_test).float())
    #
    # net = DRNet(train_set[:][0].size(1), 100, 1)
    # train(net, train_set, test_set=test_set, device='cpu', lr=1e-2, epochs=2000, batch_size=400,
    #       and_lam=1e-2, or_lam=1e-5, num_alter=500)
    # accu = (net.predict(np.array(X_test)) == Y_test).mean()
    # rules = net.get_rules()
    # print(rules)
    # print(f'Accuracy: {accu}, num rules: {len(rules)}, num conditions: {sum(map(len, rules))}')

if __name__ == "__main__":
    start = time.perf_counter()
    main()
    end = time.perf_counter()
    print(f"Time Elapsed: {end-start:.2f} seconds")