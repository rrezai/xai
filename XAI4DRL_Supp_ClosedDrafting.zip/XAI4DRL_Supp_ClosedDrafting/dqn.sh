: > dqn_experiments.txt
{
  python train_policy.py --num_agents 30 --save_name mem_dqn_explicit --policy DQN --memory --opponents Self Self Self --config MyFirstMeal
  python train_policy.py --num_agents 30 --save_name mem_dqn_implicit --policy DQN --memory --opponents Self Self Self --config MyFirstMeal

  python evaluate.py --save_name mem_dqn_explicit --agents Random Random Random DQN,agents/MyFirstMeal/mem_dqn_explicit --config MyFirstMeal --num_evals 30
  python evaluate.py --save_name mem_dqn_implicit --agents Random Random Random DQN,agents/MyFirstMeal/mem_dqn_implicit --config MyFirstMeal --num_evals 30

  python mem_diff.py --explicit results/MyFirstMeal/mem_dqn_explicit --implicit results/MyFirstMeal/mem_dqn_implicit

  python mem_influence.py --save_name mem_dqn_explicit --config MyFirstMeal

  python interpretability.py --save_name mem_dqn_explicit --config MyFirstMeal
} | tee dqn_experiments.txt
