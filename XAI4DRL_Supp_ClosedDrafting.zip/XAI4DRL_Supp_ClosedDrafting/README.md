# Closed Drafting as a Case Study for First-Principle Interpretability, Memory, and Generalizability in Deep Reinforcement Learning

This supplemental material consists of the codebase and some results/graphics that we couldn't fit into the paper.

## Supplemental Results/Graphics

`mem_dqn_explicit.png` shows the distribution of the KL divergence between action distributions of perturbed and unperturbed memory from the MemInfluence function. The expectation (the value we report in the paper) is marked by the red vertical line.

`dqn_experiments.txt` is the full raw output of the experimental runs. This contains the difference in means of explicit vs. implicit memory performances, cases from the extreme right tail of the distribution from the above figure, and the learned decision rules.

`results/MyFirstMeal` contains .csv files of the scores obtained during the evaluation of the trained DQN models, as well as figures visualizing the csv.

`represenative_agents` contains .pickle files of the worst, best, and middle DQN agents, which can be loaded in evaluate.py

## Setup

Clone the repository.

```shell
conda create --name sushi-go
conda activate sushi-go
conda install python=3.9
conda install -c conda-forge gymnasium 
pip install pettingzoo
pip install tianshou
```

## Environment Description

`sushi_go.py` contains the PettingZoo environment. It wraps a SushiGoGame in detailed `game.py`
which is responsible for all the rules and game turns.

The action space is a 37 dimensional vector representing the 37 possible cards in the game.

The observation space consists of your hand, played cards, desserts, points, round num, card num all flattened.

## Running Experiments

`train_agents.py` contains the code for training any agent. Trained agents get saved to `agents/{config}/{save_name}`.

`evaluate.py` contains the code for evaluating any agent. Evaluation results get saved to `results/{config}/{save_name}`.

For reproducing results, you can run `dqn.sh`.

For generalizability results, you can run `generalizability.sh` followed by `final_generalizability_visual.ipynb`.

## Peculiarities

Adding more models is still a WIP.

Policy Gradient Methods in Tianshou don't work with action masks. For now, we just modify the base library code. In the future, might do so differently, or push this change to Tianshou.

Modified tianshou/policy/multiagent/mapolicy.py (in process_fn)
```python
if hasattr(tmp_batch.obs, "mask"): # Deleted not
    tmp_batch.mask = tmp_batch.obs.mask # Added this line
    if hasattr(tmp_batch.obs, 'obs'):
        tmp_batch.obs = tmp_batch.obs.obs
    if hasattr(tmp_batch.obs_next, 'obs'):
        tmp_batch.obs_next = tmp_batch.obs_next.obs
results[agent] = policy.process_fn(tmp_batch, buffer, tmp_indice)
```

Modified tianshou/policy/modelfree/pg.py (in forward)
```python
if hasattr(batch.obs,"obs"):
    logits, hidden = self.actor(batch.obs.obs, state=state, info=batch.info) # This line
else:
    logits, hidden = self.actor(batch.obs, state=state, info=batch.info) # This line
if isinstance(logits, tuple):
    dist = self.dist_fn(*logits)
else:
    if hasattr(batch.obs, "mask"):
        mask = to_torch_as(batch.obs.mask, logits).bool()  # This line
    elif hasattr(batch, "mask"):
        mask = to_torch_as(batch.mask, logits).bool()  # This line
    else:
        raise NotImplementedError("Heyo expected a mask here :)") # This line
    dist = self.dist_fn(logits,mask) # This line
```