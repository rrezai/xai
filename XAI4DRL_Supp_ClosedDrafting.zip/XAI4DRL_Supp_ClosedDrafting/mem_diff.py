import argparse
import time
import pandas as pd
from scipy.stats import ttest_ind

'''
Usage: python mem_diff.py --explicit results/MyFirstMeal/dqn_explicit --implicit results/MyFirstMeal/dqn_implicit
ASSUMES TRAINED AGENT IS LAST COLUMN
'''

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--explicit", type=str, required=True, help="Explicit Memory Results Path")
    parser.add_argument("--implicit", type=str, required=True, help="Implicit Memory Results Path")
    args = parser.parse_args()

    explicit = pd.read_csv(f"{args.explicit}/scores.csv",index_col=False)
    implicit = pd.read_csv(f"{args.implicit}/scores.csv",index_col=False)

    print(f"Explicit-Implicit: {(explicit.mean()-implicit.mean())[-1]:.5g}")

    print(ttest_ind(explicit[explicit.columns[-1]],implicit[implicit.columns[-1]]))

if __name__ == "__main__":
    main()

