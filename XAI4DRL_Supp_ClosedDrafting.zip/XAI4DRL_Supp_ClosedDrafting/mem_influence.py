import argparse
import time
import dill as pickle
from env.sushi_go import SushiGoPartyEnv
from env.game import MyFirstMeal, CutthroatCombo
from pettingzoo.utils.conversions import parallel_to_aec
from tianshou.env import PettingZooEnv, DummyVectorEnv
from tianshou.data import Collector, Batch
from tianshou.policy import MultiAgentPolicyManager, RandomPolicy
import numpy as np
import torch
import torch.nn.functional as F
from scipy.stats import wasserstein_distance, entropy
import matplotlib.pyplot as plt
import copy
from utils import *

'''
Usage: python mem_influence.py --save_name results/MyFirstMeal/dqn_explicit
ASSUMES TRAINED AGENT IS LAST COLUMN
'''

def masked_log_softmax(vector, mask, dim: int = -1) -> torch.Tensor:
    vector = torch.tensor(vector)
    mask = torch.tensor(mask)
    if mask is not None:
        mask = mask.float()
        while mask.dim() < vector.dim():
            mask = mask.unsqueeze(1)
        vector = vector + ((1-mask) * -1e32)
    return F.softmax(vector, dim=dim)

def get_env(config,render_mode=None):
    if config=="MyFirstMeal":
        config = MyFirstMeal
    elif config=="CutthroatCombo":
        config = CutthroatCombo
    else:
        raise NotImplementedError(f"Config {config} not supported.")
    env = SushiGoPartyEnv(config, render_mode=render_mode)
    env = parallel_to_aec(env)
    env = PettingZooEnv(env)
    return env

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--save_name", type=str, required=True, help="Save results to filename")
    parser.add_argument("--config", type=str, required=True, help="Which config (so that we only perturb trained dimensions)")
    args = parser.parse_args()

    with open(f"agents/{args.config}/{args.save_name}/{args.save_name}_agent_0.pickle", "rb") as f:
        agent = pickle.load(f)

    distances = []
    contexts = []

    example_env = SushiGoPartyEnv(eval(args.config))
    decode_observation = example_env.game.decode_observation
    decode = example_env.game.decode
    example_env.game.deal()
    possible_cards = set(example_env.game.deck)
    for i in range(len(example_env.game.players)):
        possible_cards = possible_cards.union(example_env.game.players[i].hand)

    for i in range(100):
        env = get_env(args.config)
        policy = MultiAgentPolicyManager([RandomPolicy(),RandomPolicy(),RandomPolicy(),agent], env)
        env = DummyVectorEnv([lambda: env])
        collector = Collector(policy, env)
        steps = [19, 23, 27, 31, 55, 59, 63, 71, 91, 95, 99, 103]
        # steps = [103]
        collector.collect(n_step=steps[np.random.randint(0,len(steps))], render=None)
        base = masked_log_softmax(agent(Batch(obs=collector.data.obs,info=None)).logits.detach(),collector.data.obs.mask).numpy().flatten()

        for j in range(10):
            perturbed_obs = copy.deepcopy(collector.data.obs)
            for k in range(1):
                last_player_hand = decode(perturbed_obs.obs[0][3*37:4*37])
                card_to_change = np.random.randint(0,len(last_player_hand))
                new_card = np.random.choice(list(possible_cards - {last_player_hand[card_to_change], }), 1).item()
                perturbed_obs.obs[0][3*37+last_player_hand[card_to_change].id]-=1
                perturbed_obs.obs[0][3*37+new_card.id]+=1
            perturbed = masked_log_softmax(agent(Batch(obs=perturbed_obs,info=None)).logits.detach(),perturbed_obs.mask).numpy().flatten()
            # distance = wasserstein_distance(range(len(base)),range(len(base)),base,perturbed)
            distance = entropy(perturbed,base)
            # distance = np.linalg.norm(base-perturbed)
            distances.append(distance)
            contexts.append((collector.data.obs,perturbed_obs,base,perturbed,distance))

    print("Distance",np.mean(distances))

    sorted_indices = np.array(distances).argsort()[::-1]
    sorted_contexts = [contexts[i] for i in sorted_indices]

    for i in range(5):
        original_obs, perturbed_obs, base_dist, perturbed_dist, distance = sorted_contexts[i]
        print(decode_observation(original_obs.obs[0]))
        print(decode_observation(perturbed_obs.obs[0]))
        print(base_dist)
        print(perturbed_dist)
        print(distance)
        print()

    plt.hist(distances,bins=50)
    plt.grid()
    plt.legend()
    plt.ylabel("Frequency")
    plt.xlabel("Distance")
    plt.title("Memory Influence Distribution (Mean Marked)")
    plt.axvline(np.mean(distances),color="red")
    plt.savefig(f"{args.save_name}.png")
    # Actually, should compare to random noise instead of masking...comparing to zero is pointless...also use high distances for case study



if __name__ == "__main__":
    start = time.perf_counter()
    main()
    end = time.perf_counter()
    print(f"Time Elapsed: {end-start:.2f} seconds")

