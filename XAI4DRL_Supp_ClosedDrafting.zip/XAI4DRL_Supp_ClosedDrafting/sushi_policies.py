from typing import Any, Dict, Optional, Union
from env.sushi_go import SushiGoPartyEnv
from env.game import SushiGoPartyGame, MyFirstMeal
from env.cards import *
from pettingzoo.utils.conversions import parallel_to_aec
from tianshou.env import PettingZooEnv, DummyVectorEnv
from tianshou.data import Collector
from tianshou.policy import MultiAgentPolicyManager, RandomPolicy, DQNPolicy
from tianshou.data import Batch
from tianshou.policy import BasePolicy
import copy
import numpy as np
import pandas as pd

class ManualPolicy(BasePolicy):
    def forward(self, batch: Batch, state: Optional[Union[dict, Batch, np.ndarray]] = None, **kwargs: Any,) -> Batch:
        mask = batch.obs.mask[0]
        observation = SushiGoPartyGame(MyFirstMeal).decode_observation(batch.obs.obs[0])
        played_cards = observation['played_cards'][0]
        desserts = observation['desserts'][0]
        round_num = observation['round']
        card_num = observation['card_num']
        logits = np.random.rand(*mask.shape)
        logits[~mask] = -np.inf
        # First, prioritize completing any sets
        # Complete Green Tea Ice Cream set
        if (played_cards.count('GreenTeaIceCream')+desserts.count('GreenTeaIceCream')) % 4 == 3 and mask[29]:
            return (Batch(act=np.array([29], dtype=np.int64)))
        # Complete Sashimi set
        if played_cards.count('Sashimi') == 2 and mask[18]:
            return (Batch(act=np.array([18], dtype=np.int64)))
        # Complete Eel set
        if played_cards.count('Eel') == 1 and mask[12]:
            return (Batch(act=np.array([12], dtype=np.int64)))
        # Complete Tempura set
        if played_cards.count('Tempura') % 2 == 1 and mask[19]:
            return (Batch(act=np.array([19], dtype=np.int64)))

        # Second, any set-building cards if early enough
        if card_num<=3:
            # Pick Sashimi
            if played_cards.count('Sashimi') < 2 and mask[18]:
                return (Batch(act=np.array([18], dtype=np.int64)))
            # Pick Eel
            if played_cards.count('Eel') < 1 and mask[12]:
                return (Batch(act=np.array([12], dtype=np.int64)))
        if round_num<=2:
            # Pick Green Tea Ice Cream
            if played_cards.count('GreenTeaIceCream') < 4 and mask[29]:
                return (Batch(act=np.array([29], dtype=np.int64)))

        # Third, any S-tier cards
        # Pick any Fruit
        for fruit in [31,32,33,34,35,36]:
            if mask[fruit]:
                return (Batch(act=np.array([fruit], dtype=np.int64)))
        # Pick Squid Nigiri
        if mask[2]:
            return (Batch(act=np.array([2], dtype=np.int64)))
        # Pick unique Onigiri
        if played_cards.count("TriangleOnigiri")==0 and mask[13]:
            return (Batch(act=np.array([13], dtype=np.int64)))
        if played_cards.count("CircleOnigiri")==0 and mask[14]:
            return (Batch(act=np.array([14], dtype=np.int64)))
        if played_cards.count("SquareOnigiri")==0 and mask[15]:
            return (Batch(act=np.array([15], dtype=np.int64)))
        if played_cards.count("FlatOnigiri")==0 and mask[16]:
            return (Batch(act=np.array([16], dtype=np.int64)))

        # Fourth, any A-Tier cards
        # Pick Three Maki
        if mask[5]:
            return (Batch(act=np.array([5], dtype=np.int64)))
        # Pick Five Uramaki
        if mask[9]:
            return (Batch(act=np.array([9], dtype=np.int64)))
        # Pick Tea
        if mask[27]:
            return (Batch(act=np.array([27], dtype=np.int64)))
        # Pick Soy Sauce
        if mask[23]:
            return (Batch(act=np.array([23], dtype=np.int64)))
        # Pick Tofu
        if played_cards.count('Tofu') < 2 and mask[20]:
            return (Batch(act=np.array([20], dtype=np.int64)))
        # Pick Tempura
        if played_cards.count('Tempura') < 2 and mask[19]:
            return (Batch(act=np.array([19], dtype=np.int64)))
        # Pick Salmon Nigiri
        if mask[1]:
            return (Batch(act=np.array([1], dtype=np.int64)))
        # Pick Two Maki
        if mask[4]:
            return (Batch(act=np.array([4], dtype=np.int64)))
        # Pick Four Uramaki
        if mask[8]:
            return (Batch(act=np.array([8], dtype=np.int64)))
        # Pick Pudding
        if mask[30]:
            return (Batch(act=np.array([30], dtype=np.int64)))

        # Fifth, any B-Tier cards
        # Pick Temaki
        if mask[6]:
            return (Batch(act=np.array([6], dtype=np.int64)))
        # Pick Miso Soup
        if mask[17]:
            return (Batch(act=np.array([17], dtype=np.int64)))
        # Pick Dumpling
        if mask[10]:
            return (Batch(act=np.array([10], dtype=np.int64)))
        # Pick One Maki
        if mask[3]:
            return (Batch(act=np.array([3], dtype=np.int64)))
        # Pick Three Uramaki
        if mask[7]:
            return (Batch(act=np.array([7], dtype=np.int64)))
        # Pick Egg Nigiri
        if mask[0]:
            return (Batch(act=np.array([0], dtype=np.int64)))
        # Otherwise, pick randomly
        return Batch(act=[logits.argmax(axis=-1)], dtype=np.int64)

    def learn(self, batch: Batch, **kwargs: Any) -> Dict[str, float]:
        return {}

class AverageRankedPolicy(BasePolicy):
    #
    def forward(self, batch: Batch, state: Optional[Union[dict, Batch, np.ndarray]] = None, **kwargs: Any,) -> Batch:
        mask = batch.obs.mask
        ranked = np.array([1, 2, 20, 13, 14, 15, 16, 17, 19, 10, 5, 4, 3, 18, 12, 28, 29, 0, 11, 27, 9, 8, 7, 31, 32, 33, 34, 35, 36, 23, 26, 6, 30])
        choices = ranked[np.argmax(mask[:, ranked], axis=-1)]
        return Batch(act=choices,dtype=np.int64)

    def learn(self, batch: Batch, **kwargs: Any) -> Dict[str, float]:
        return {}


class WinnerRankedPolicy(BasePolicy):
    def forward(self, batch: Batch, state: Optional[Union[dict, Batch, np.ndarray]] = None, **kwargs: Any,) -> Batch:
        mask = batch.obs.mask
        ranked = np.array([2, 1, 20, 13, 14, 15, 16, 17, 18, 5, 4, 3, 12, 19, 28, 29, 10, 9, 8, 7, 0, 27, 11, 31, 32, 33, 34, 35, 36, 6, 23, 30, 26])
        choices = ranked[np.argmax(mask[:, ranked], axis=-1)]
        return Batch(act=choices, dtype=np.int64)

    def learn(self, batch: Batch, **kwargs: Any) -> Dict[str, float]:
        return {}

if __name__ == "__main__":
    # Random Agent 1,2,3 vs. Manual Policy Agent 4
    env = SushiGoPartyEnv(MyFirstMeal,render_mode="ansi")
    env = parallel_to_aec(env)
    env = PettingZooEnv(env)
    policy = MultiAgentPolicyManager([RandomPolicy(), RandomPolicy(), RandomPolicy(), WinnerRankedPolicy()], env)
    env = DummyVectorEnv([lambda: env])
    collector = Collector(policy, env)
    result = collector.collect(n_episode=1, render=0.01)